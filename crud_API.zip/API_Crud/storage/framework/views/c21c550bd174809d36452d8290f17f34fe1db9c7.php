<!doctype html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <style type="text/css">
    a{
      position: relative;
    left: 45px;
    top: 25px;
    }
    .button {
  width: 50px;
  height: 50px;
  border-radius: 50%;
  background-color: rgb(20, 20, 20);
  border: none;
  font-weight: 600;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0px 0px 0px 4px rgba(180, 160, 255, 0.253);
  cursor: pointer;
  transition-duration: 0.3s;
  overflow: hidden;
  position: relative;
}

.svgIcon {
  width: 12px;
  transition-duration: 0.3s;
}

.svgIcon path {
  fill: white;
}

.button:hover {
  width: 140px;
  border-radius: 50px;
  transition-duration: 0.3s;
  background-color: rgb(181, 160, 255);
  align-items: center;
}

.button:hover .svgIcon {
  /* width: 20px; */
  transition-duration: 0.3s;
  transform: translateY(-200%);
}

.button::before {
  position: absolute;
  bottom: -20px;
  content: "Back to Home";
  color: white;
  /* transition-duration: .3s; */
  font-size: 0px;
}

.button:hover::before {
  font-size: 13px;
  opacity: 1;
  bottom: unset;
  /* transform: translateY(-30px); */
  transition-duration: 0.3s;
}
  </style>
</head>
<body>
  <a href=" <?php echo e(route('index')); ?> " class="button">
  <svg class="svgIcon" viewBox="0 0 384 512">
    <path
      d="M214.6 41.4c-12.5-12.5-32.8-12.5-45.3 0l-160 160c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L160 141.2V448c0 17.7 14.3 32 32 32s32-14.3 32-32V141.2L329.4 246.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3l-160-160z"
    ></path>
  </svg>
</a>
  <div class="flex flex-col items-center justify-center h-screen dark">
  <div class="w-full max-w-md bg-gray-800 rounded-lg shadow-md p-6">
    <h2 class="text-2xl font-bold text-gray-200 mb-4">Add Product Form</h2>
    <form class="flex flex-col" method="post" action="<?php echo e(route('store')); ?>" enctype="multipart/form-data" id="productForm">
      <?php echo csrf_field(); ?>
      <input placeholder="product Name" class="bg-gray-700 text-gray-200 border-0 rounded-md p-2 mb-4 focus:bg-gray-600 focus:outline-none focus:ring-1 focus:ring-blue-500 transition ease-in-out duration-150" type="text" name="name" id="name" required>
      <input placeholder="Price" class="bg-gray-700 text-gray-200 border-0 rounded-md p-2 mb-4 focus:bg-gray-600 focus:outline-none focus:ring-1 focus:ring-blue-500 transition ease-in-out duration-150" type="number" name="price" id="price" required>
      <textarea placeholder="Description of product here!" class="bg-gray-700 text-gray-200 border-0 rounded-md p-2 mb-4 focus:bg-gray-600 focus:outline-none focus:ring-1 focus:ring-blue-500 transition ease-in-out duration-150" name="desc" id="desc" required></textarea>
      <input placeholder="image" class="bg-gray-700 text-gray-200 border-0 rounded-md p-2 mb-4 focus:bg-gray-600 focus:outline-none focus:ring-1 focus:ring-blue-500 transition ease-in-out duration-150" type="file" name="image" id="image" accept=".jpg, .jpeg, .png, .gif, .bmp" required>
      <input class="bg-gradient-to-r from-indigo-500 to-blue-500 text-white font-bold py-2 px-4 rounded-md mt-4 hover:bg-indigo-600 hover:to-blue-600 transition ease-in-out duration-150" type="submit" value="Apply">
    </form>
  </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script type="text/javascript">
  $(document).ready(function () {
      $("#productForm").submit(function () {
        // Perform your validation here
        var name = $("#name").val().trim();
        var price = $("#price").val();
        var desc = $("#desc").val().trim();
        var image = $("#image").val();

        // Basic validation example, you can add more specific validation as needed
        if (name === "" || price === "" || desc === "" || image === "") {
          alert("Please fill in all fields.");
          return false;
        }
        else if (name.length < 3 || name.length > 50) {
        alert("Product name must be between 3 and 50 characters"); 
        return false;
      }else if (!/^[a-zA-Z\s]*$/.test(name)) {
        alert("Product name should not contain numeric or special characters");
        return false;      }
      else if (isNaN(price)) {
          alert(`Please enter a valid price ${price}`);
          return false;
        }
        else if (desc.length < 3 || desc.length > 100) {
        alert("Product description must be between 3 and 100 characters");
        return false; 
      }else if (!/^[a-zA-Z\s]*$/.test(desc)) {
        alert("Product description should not contain numeric or special characters");
        return false;
      }
      else {
        alert("Form submitted successfully!");
        return true;
      }
      });
    });
</script>
</body>
</html><?php /**PATH /var/www/html/API_Crud/resources/views/create.blade.php ENDPATH**/ ?>